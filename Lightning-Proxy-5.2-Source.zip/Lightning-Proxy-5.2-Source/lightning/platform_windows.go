package main

import (
	_ "embed"
	"encoding/json"
	"errors"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"syscall"
	"unsafe"
)

const exeSuffix = ".exe"
const tunnelInterface = "LightningTunnel"

//go:embed panel.ps1
var panel string

func hidden(path string, args ...string) *exec.Cmd {
	c := exec.Command(path, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	return c
}
func signalTunnel(pid int) {
	syscall.NewLazyDLL("kernel32.dll").NewProc("GenerateConsoleCtrlEvent").Call(1, uintptr(pid))
}
func (s *state) startSystemProxy() error { return errors.New("System Proxy is available on macOS.") }
func tunnelAvailable() bool              { return true }
func usesTunnel() bool {
	iface, err := net.InterfaceByName(tunnelInterface)
	if err != nil || iface.Flags&net.FlagUp == 0 {
		return false
	}
	var index uint32
	// GetBestInterface expects an IPv4 address in network byte order.
	code, _, _ := syscall.NewLazyDLL("iphlpapi.dll").NewProc("GetBestInterface").Call(0x01000001, uintptr(unsafe.Pointer(&index)))
	return code == 0 && index == uint32(iface.Index)
}

func (s *state) shutdownTunnel() { signalTunnel(s.tun.Process.Pid) }
func (s *state) startTunnel(ip string, quad bool) (err error) {
	data, _ := json.Marshal(routing(ip, quad))
	f, e := os.CreateTemp("", "cheesy-tun-*.json")
	if e != nil {
		return errors.New("Kon geen tijdelijke tunnelconfiguratie maken.")
	}
	s.tunConfig = f.Name()
	_, e = f.Write(data)
	f.Close()
	if e != nil {
		return errors.New("Kon de tunnelconfiguratie niet schrijven.")
	}
	s.tun = hidden(filepath.Join(s.dir, "sing-box.exe"), "run", "-c", s.tunConfig)
	s.tun.Dir = s.dir
	s.tun.SysProcAttr.CreationFlags = 0x00000200
	if s.tunDone, err = launch(s.tun); err != nil {
		return errors.New("De tunnelmodule kon niet starten.")
	}
	return nil
}
func main() {
	path, e := os.Executable()
	if e != nil {
		return
	}
	dir := filepath.Dir(path)
	if len(os.Args) > 1 && os.Args[1] == "--engine" {
		kernel := syscall.NewLazyDLL("kernel32.dll")
		kernel.NewProc("AllocConsole").Call()
		if window, _, _ := kernel.NewProc("GetConsoleWindow").Call(); window != 0 {
			syscall.NewLazyDLL("user32.dll").NewProc("ShowWindow").Call(window, 0)
		}
		runEngine(dir)
		return
	}
	// The window runs in Windows PowerShell's STA host. No browser or downloads at launch.
	temp, e := os.CreateTemp("", "lightning-proxy-*.ps1")
	if e != nil {
		return
	}
	defer os.Remove(temp.Name())
	temp.WriteString("\ufeff" + panel)
	temp.Close()
	shell := filepath.Join(os.Getenv("SystemRoot"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
	args := []string{"-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", temp.Name(), path}
	if len(os.Args) == 3 && os.Args[1] == "--resume" {
		if index, err := strconv.Atoi(os.Args[2]); err == nil && index >= 0 && index < 100 {
			args = append(args, "-ResumeIndex", strconv.Itoa(index))
		}
	}
	cmd := hidden(shell, args...)
	_ = cmd.Run()
}
