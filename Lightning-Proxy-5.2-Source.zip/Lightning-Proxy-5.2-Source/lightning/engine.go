package main

import (
	"bytes"
	"context"

	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"

	"time"
)

type obj = map[string]any
type profile struct {
	Name, Host, Link string
	Port             int
	User             obj
	Reality          obj
}
type state struct {
	core, tun         *exec.Cmd
	coreDone, tunDone chan struct{}
	tunConfig         string
	tunInput          io.WriteCloser
	profiles          []profile
	dir               string
}

func parse(s string) (profile, error) {
	u, e := url.Parse(strings.ReplaceAll(s, `vless\://`, "vless://"))
	if e != nil || u.Scheme != "vless" || u.User == nil || u.Hostname() == "" {
		return profile{}, errors.New("Invalid VLESS link.")
	}
	port, e := strconv.Atoi(u.Port())
	q := u.Query()
	key, k := base64.RawURLEncoding.DecodeString(q.Get("pbk"))
	sid, h := hex.DecodeString(q.Get("sid"))
	id, i := hex.DecodeString(strings.ReplaceAll(u.User.Username(), "-", ""))
	if e != nil || port < 1 || port > 65535 || k != nil || len(key) != 32 || h != nil || len(sid) > 8 || i != nil || len(id) != 16 || q.Get("security") != "reality" || q.Get("sni") == "" || (q.Get("type") != "" && q.Get("type") != "tcp" && q.Get("type") != "raw") || (q.Get("flow") != "" && q.Get("flow") != "xtls-rprx-vision") || (q.Get("encryption") != "" && q.Get("encryption") != "none") || q.Get("pqv") != "" || q.Get("fm") != "" {
		return profile{}, errors.New("Use VLESS REALITY over TCP, optionally with XTLS Vision.")
	}
	name, fp := u.Fragment, q.Get("fp")
	if name == "" {
		name = u.Hostname()
	}
	if fp == "" {
		fp = "chrome"
	}
	return profile{name, u.Hostname(), u.String(), port, obj{"id": u.User.Username(), "flow": q.Get("flow"), "encryption": "none"}, obj{"publicKey": q.Get("pbk"), "serverName": q.Get("sni"), "shortId": q.Get("sid"), "spiderX": q.Get("spx"), "fingerprint": fp}}, nil
}
func load(input string, download bool) ([]profile, error) {
	input = strings.TrimSpace(input)
	if download && strings.HasPrefix(input, "https://") {
		c := http.Client{Timeout: 12 * time.Second, CheckRedirect: func(r *http.Request, via []*http.Request) error {
			if r.URL.Scheme != "https" || len(via) >= 5 {
				return http.ErrUseLastResponse
			}
			return nil
		}}
		r, e := http.NewRequest("GET", input, nil)
		if e != nil {
			return nil, errors.New("Invalid subscription link.")
		}
		r.Header.Set("User-Agent", "v2rayN/7.0")
		res, e := c.Do(r)
		if e != nil {
			return nil, errors.New("Could not download the subscription.")
		}
		defer res.Body.Close()
		if res.StatusCode != 200 {
			return nil, fmt.Errorf("Subscription returned HTTP %d.", res.StatusCode)
		}
		b, e := io.ReadAll(io.LimitReader(res.Body, 1048577))
		if e != nil || len(b) > 1048576 {
			return nil, errors.New("Subscription is too large or unreadable.")
		}
		input = strings.TrimSpace(string(b))
	}
	if !strings.Contains(input, "vless") {
		compact := strings.TrimRight(strings.Join(strings.Fields(input), ""), "=")
		for _, encoding := range []*base64.Encoding{base64.RawStdEncoding, base64.RawURLEncoding} {
			if b, e := encoding.DecodeString(compact); e == nil {
				input = string(b)
				break
			}
		}
	}
	var profiles []profile
	for _, line := range strings.Fields(strings.TrimPrefix(input, "\ufeff")) {
		if p, e := parse(line); e == nil {
			profiles = append(profiles, p)
		}
		if len(profiles) == 100 {
			break
		}
	}
	if len(profiles) == 0 {
		return nil, errors.New("No valid VLESS REALITY profile found.")
	}
	return profiles, nil
}
func launch(c *exec.Cmd) (chan struct{}, error) {
	if e := c.Start(); e != nil {
		return nil, e
	}
	done := make(chan struct{})
	go func() { c.Wait(); close(done) }()
	return done, nil
}
func alive(done chan struct{}) bool {
	if done == nil {
		return false
	}
	select {
	case <-done:
		return false
	default:
		return true
	}
}
func kill(c *exec.Cmd, done chan struct{}) {
	if alive(done) {
		_ = c.Process.Kill()
		<-done
	}
}
func (s *state) stop() {
	if alive(s.tunDone) {
		s.shutdownTunnel()
		select {
		case <-s.tunDone:
		case <-time.After(3 * time.Second):
		}
	}
	kill(s.tun, s.tunDone)
	kill(s.core, s.coreDone)
	s.tunDone, s.coreDone = nil, nil
	if s.tunConfig != "" {
		_ = os.Remove(s.tunConfig)
		s.tunConfig = ""
	}
}
func configuration(p profile, ip string) obj {
	return obj{"log": obj{"loglevel": "none"}, "inbounds": []obj{
		{"listen": "127.0.0.1", "port": 10808, "protocol": "socks", "settings": obj{"udp": true, "ip": "127.0.0.1"}},
		{"listen": "127.0.0.1", "port": 10809, "protocol": "http"},
	}, "outbounds": []obj{{"protocol": "vless", "settings": obj{"vnext": []obj{{"address": ip, "port": p.Port, "users": []obj{p.User}}}},
		"streamSettings": obj{"network": "tcp", "security": "reality", "realitySettings": p.Reality}}}}
}
func routing(ip string, quad bool) obj {
	suffix, dns, server := "/32", "1.1.1.1", "cloudflare-dns.com"
	if strings.Contains(ip, ":") {
		suffix = "/128"
	}
	if quad {
		dns, server = "9.9.9.9", "dns.quad9.net"
	}
	return obj{"log": obj{"level": "error"}, "dns": obj{"servers": []obj{{"type": "https", "tag": "remote", "server": dns, "tls": obj{"enabled": true, "server_name": server}, "detour": "proxy"}}, "final": "remote"},
		"inbounds":  []obj{{"type": "tun", "interface_name": tunnelInterface, "address": []string{"172.31.255.1/30", "fd7a:91f3:87b1::1/126"}, "mtu": 1400, "auto_route": true, "stack": "mixed", "route_exclude_address": []string{ip + suffix}}},
		"outbounds": []obj{{"type": "socks", "tag": "proxy", "server": "127.0.0.1", "server_port": 10808, "version": "5"}}, "route": obj{"final": "proxy", "rules": []obj{{"port": 53, "action": "hijack-dns"}}}}
}
func probe(device bool) (obj, error) {
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	tr := &http.Transport{}
	if !device {
		proxy, _ := url.Parse("http://127.0.0.1:10809")
		tr.Proxy = http.ProxyURL(proxy)
	}
	defer tr.CloseIdleConnections()
	client := http.Client{Transport: tr, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	targets := []string{"https://www.cloudflare.com/cdn-cgi/trace", "https://www.gstatic.com/generate_204", "https://example.com/"}
	results := make(chan obj, len(targets))
	for _, target := range targets {
		go func() {
			start := time.Now()
			req, _ := http.NewRequestWithContext(ctx, http.MethodGet, target, nil)
			res, e := client.Do(req)
			if e != nil {
				results <- nil
				return
			}
			defer res.Body.Close()
			info := obj{"latency": time.Since(start).Milliseconds()}
			if strings.HasSuffix(target, "/cdn-cgi/trace") {
				b, _ := io.ReadAll(io.LimitReader(res.Body, 8192))
				for _, line := range strings.Split(string(b), "\n") {
					if ip := strings.TrimPrefix(line, "ip="); line != ip && net.ParseIP(ip) != nil {
						info["ip"] = ip
						break
					}
				}
			}
			results <- info
		}()
	}
	var first obj
	for range targets {
		r := <-results
		if r == nil {
			continue
		}
		if r["ip"] != nil {
			return r, nil
		}
		if first == nil {
			first = r
		}
	}
	if first != nil {
		return first, nil
	}
	if device {
		return nil, errors.New("Tunnel routes are active, but no HTTPS test site replied. Check your gateway and DNS.")
	}
	return nil, errors.New("The local proxy started, but no HTTPS test site replied through VLESS. Check that the profile is current and the gateway is reachable.")
}

func (s *state) connect(index int, device, quad, system bool) (info obj, err error) {
	if alive(s.coreDone) {
		return nil, errors.New("Disconnect the current session first.")
	}
	if index < 0 || index >= len(s.profiles) {
		return nil, errors.New("Import and select a profile first.")
	}
	p := s.profiles[index]
	for _, port := range []string{"10808", "10809"} {
		listener, e := net.Listen("tcp4", "127.0.0.1:"+port)
		if e != nil {
			return nil, fmt.Errorf("Port %s is already in use.", port)
		}
		listener.Close()
	}
	ip := p.Host
	if device {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		ips, e := net.DefaultResolver.LookupIPAddr(ctx, p.Host)
		cancel()
		if e != nil || len(ips) == 0 {
			return nil, errors.New("Could not resolve the gateway address.")
		}
		ip = ips[0].IP.String()
		for _, v := range ips {
			if v.IP.To4() != nil {
				ip = v.IP.String()
				break
			}
		}
	}
	defer func() {
		if err != nil {
			s.stop()
		}
	}()
	data, _ := json.Marshal(configuration(p, ip))
	binaries := []string{"xray" + exeSuffix}
	if _, e := os.Stat(filepath.Join(s.dir, "xray-legacy"+exeSuffix)); e == nil {
		binaries = append(binaries, "xray-legacy"+exeSuffix)
	}
	var startErr error
	for _, binary := range binaries {
		s.core = hidden(filepath.Join(s.dir, binary), "run", "-format", "json", "-config", "stdin:")
		s.core.Stdin = bytes.NewReader(data)
		if s.coreDone, startErr = launch(s.core); startErr != nil {
			startErr = errors.New("Xray could not start. Keep all application files together.")
			continue
		}
		ready := false
		for i := 0; i < 45 && alive(s.coreDone); i++ {
			if c, e := net.DialTimeout("tcp4", "127.0.0.1:10809", 100*time.Millisecond); e == nil {
				c.Close()
				ready = true
				break
			}
			time.Sleep(70 * time.Millisecond)
		}
		startErr = errors.New("Xray exited before the local proxy was ready.")
		if ready {
			info, startErr = probe(false)
		}
		if startErr == nil {
			break
		}
		kill(s.core, s.coreDone)
		s.coreDone = nil
	}
	if startErr != nil {
		return nil, startErr
	}

	if device {
		if err = s.startTunnel(ip, quad); err != nil {
			return nil, err
		}
		ready := false
		for i := 0; i < 100 && alive(s.tunDone); i++ {
			if usesTunnel() {
				ready = true
				break
			}
			time.Sleep(100 * time.Millisecond)
		}
		if !ready {
			return nil, errors.New("The device tunnel did not install its IPv4 route. Check system permissions or another active VPN.")
		}
		time.Sleep(300 * time.Millisecond)
		info, err = probe(true)
		if err != nil {
			return nil, err
		}
	}
	if system && !device {
		if err = s.startSystemProxy(); err != nil {
			return nil, err
		}
	}
	info["host"] = p.Host
	return info, nil
}

func profileNames(profiles []profile) []string {
	names := make([]string, 0, len(profiles))
	for _, p := range profiles {
		names = append(names, p.Name+"  ·  "+p.Host)
	}
	return names
}
func profilePath() (string, error) {
	base, e := os.UserConfigDir()
	if e != nil {
		return "", e
	}
	return filepath.Join(base, "Lightning Proxy", "profiles"), nil
}
func saveProfileLinks(links string) error {
	path, e := profilePath()
	if e != nil {
		return e
	}
	dir := filepath.Dir(path)
	if e = os.MkdirAll(dir, 0700); e != nil {
		return e
	}
	f, e := os.CreateTemp(dir, "profiles-")
	if e != nil {
		return e
	}
	defer os.Remove(f.Name())
	_, e = f.WriteString(links)
	closeErr := f.Close()
	if e != nil {
		return e
	}
	if closeErr != nil {
		return closeErr
	}
	return os.Rename(f.Name(), path)
}
func runEngine(dir string) {
	s := state{dir: dir}
	defer s.stop()
	dec, enc := json.NewDecoder(os.Stdin), json.NewEncoder(os.Stdout)
	for {
		var req struct {
			Action, Input        string
			Index                int
			Device, Quad, System bool
		}
		if dec.Decode(&req) != nil {
			return
		}
		var err error
		result := obj{}
		switch req.Action {
		case "load":
			result["tunnelReady"] = tunnelAvailable()
			path, e := profilePath()
			if e != nil {
				err = e
				break
			}
			data, e := os.ReadFile(path)
			if errors.Is(e, os.ErrNotExist) {
				break
			}
			if e != nil {
				err = errors.New("Could not read saved profiles.")
				break
			}
			s.profiles, err = load(string(data), false)
			if err == nil {
				result["profiles"] = profileNames(s.profiles)
			}
		case "import", "restore":
			if alive(s.coreDone) {
				err = errors.New("Disconnect before editing profiles.")
				break
			}
			var profiles []profile
			profiles, err = load(req.Input, req.Action == "import")
			if err == nil {
				s.profiles = profiles
				links, names := []string{}, []string{}
				for _, p := range profiles {
					links = append(links, p.Link)
					names = append(names, p.Name+"  ·  "+p.Host)
				}
				if exeSuffix != "" {
					result["links"] = strings.Join(links, "\n")
				}
				result["profiles"] = names
				if exeSuffix == "" && req.Action == "import" {
					if e := saveProfileLinks(strings.Join(links, "\n")); e != nil {
						result["warning"] = "Profile loaded, but it could not be saved."
					}
				}
			}
		case "connect":
			result["info"], err = s.connect(req.Index, req.Device, req.Quad, req.System)
		case "test":
			result["info"], err = probe(req.Device)
		case "status":
		case "stop", "quit":
			s.stop()
		}
		result["active"] = alive(s.coreDone) && (!req.Device || (alive(s.tunDone) && usesTunnel())) && (!req.System || alive(s.tunDone))
		if err != nil {
			result["error"] = err.Error()
		}
		if enc.Encode(result) != nil || req.Action == "quit" {
			return
		}
	}
}
