//go:build windows

package main

import (
	_ "embed"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"syscall"
)

//go:embed panel.ps1
var panel string

func main() {
	path, err := os.Executable()
	if err != nil {
		return
	}
	file, err := os.CreateTemp("", "lightning-ui-*.ps1")
	if err != nil {
		return
	}
	defer os.Remove(file.Name())
	_, err = file.WriteString("\ufeff" + panel)
	closeErr := file.Close()
	if err != nil || closeErr != nil {
		return
	}
	shell := filepath.Join(os.Getenv("SystemRoot"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
	engine := filepath.Join(filepath.Dir(path), "proxy-engine.exe")
	args := []string{"-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-File", file.Name(), "-Exe", engine, "-Launcher", path}
	if len(os.Args) == 3 && os.Args[1] == "--resume" {
		if index, err := strconv.Atoi(os.Args[2]); err == nil && index >= 0 && index < 100 {
			args = append(args, "-ResumeIndex", strconv.Itoa(index))
		}
	}
	command := exec.Command(shell, args...)
	command.SysProcAttr = &syscall.SysProcAttr{HideWindow: true}
	_ = command.Run()
}
