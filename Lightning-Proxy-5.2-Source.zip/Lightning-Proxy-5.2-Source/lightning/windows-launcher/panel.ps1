param([string]$Exe,[string]$Launcher,[int]$ResumeIndex = -1)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms,System.Drawing,System.Security
[Windows.Forms.Application]::EnableVisualStyles()
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
$admin = $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)

$start = New-Object Diagnostics.ProcessStartInfo
$start.FileName = $Exe
$start.Arguments = '--engine'
$start.UseShellExecute = $false
$start.CreateNoWindow = $true
$start.RedirectStandardInput = $true
$start.RedirectStandardOutput = $true
$start.StandardOutputEncoding = New-Object Text.UTF8Encoding($false)
$engine = [Diagnostics.Process]::Start($start)
$utf8 = New-Object Text.UTF8Encoding($false)
$inputStream = New-Object IO.StreamWriter($engine.StandardInput.BaseStream,$utf8)
$inputStream.AutoFlush = $true

$script:state = 'idle'
$script:pending = $null
$script:action = ''
$script:active = $false
$script:quitting = $false
$script:connectedAt = $null
$script:info = $null
$script:lastStatus = [DateTime]::UtcNow
$storeDir = Join-Path $env:LOCALAPPDATA 'Lightning Proxy'
$store = Join-Path $storeDir 'profiles.dat'
$pref = Join-Path $storeDir 'settings.json'
$prefs = $null
if (Test-Path -LiteralPath $pref) { try { $prefs = Get-Content -Raw -LiteralPath $pref | ConvertFrom-Json } catch {} }

$colorBg = [Drawing.Color]::FromArgb(11,16,30)
$colorCard = [Drawing.Color]::FromArgb(21,27,44)
$colorText = [Drawing.Color]::FromArgb(239,242,255)
$colorMuted = [Drawing.Color]::FromArgb(166,181,209)
$colorCyan = [Drawing.Color]::FromArgb(230,252,141)

$form = New-Object Windows.Forms.Form
$form.Text = 'Lightning Proxy 5.2'
$form.ClientSize = New-Object Drawing.Size(790,490)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'
$form.BackColor = $colorBg
$form.ForeColor = $colorText
$form.Font = New-Object Drawing.Font('Segoe UI',10)
$form.Icon = [Drawing.SystemIcons]::Shield
$iconPath = Join-Path (Split-Path -Parent $Launcher) 'Lightning.ico'
if (Test-Path -LiteralPath $iconPath) { $form.Icon = New-Object Drawing.Icon($iconPath) }

function Place($control,$parent,$x,$y,$w,$h) {
    $control.SetBounds($x,$y,$w,$h)
    $parent.Controls.Add($control)
}
function Label($text,$parent,$x,$y,$w,$h,$size=10,$bold=$false) {
    $control = New-Object Windows.Forms.Label
    $control.Text = $text
    $control.ForeColor = $colorText
    $style = if ($bold) { [Drawing.FontStyle]::Bold } else { [Drawing.FontStyle]::Regular }
    $control.Font = New-Object Drawing.Font('Segoe UI',$size,$style)
    Place $control $parent $x $y $w $h
    return $control
}
function Button($text,$parent,$x,$y,$w,$h) {
    $control = New-Object Windows.Forms.Button
    $control.Text = $text
    $control.FlatStyle = 'Flat'
    $control.BackColor = [Drawing.Color]::FromArgb(34,43,65)
    $control.ForeColor = $colorText
    Place $control $parent $x $y $w $h
    return $control
}
$mark = Label 'ϟ' $form 24 24 40 40 20 $true
$mark.BackColor = $colorCyan
$mark.ForeColor = $colorBg
$mark.TextAlign = 'MiddleCenter'
$null = Label 'Lightning Proxy' $form 78 20 380 46 24 $true
$settings = Button 'Settings' $form 635 28 130 34

$left = New-Object Windows.Forms.Panel
$left.BackColor = $colorCard
Place $left $form 24 83 265 315
$right = New-Object Windows.Forms.Panel
$right.BackColor = $colorCard
Place $right $form 308 83 458 315
$mode = Label '' $left 8 19 249 24 11 $true
$mode.TextAlign = 'MiddleCenter'
$mode.ForeColor = $colorCyan
$connect = Button '' $left 53 55 159 159
$connect.AccessibleName = 'Connect or disconnect'
$ellipse = New-Object Drawing.Drawing2D.GraphicsPath
$ellipse.AddEllipse(0,0,158,158)
$connect.Region = New-Object Drawing.Region($ellipse)
$ellipse.Dispose()
$connect.FlatAppearance.BorderSize = 0
$connect.BackColor = $colorCyan
$connect.ForeColor = $colorBg
$connect.Font = New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold)
$motion = [Windows.Forms.SystemInformation]::IsMenuAnimationEnabled
$left.Add_Paint({
    param($sender,$event)
    $g=$event.Graphics
    $g.SmoothingMode='AntiAlias'
    $track=New-Object Drawing.Pen([Drawing.Color]::FromArgb(53,67,94),1)
    $arc=New-Object Drawing.Pen($colorCyan,2.4)
    try {
        $g.DrawEllipse($track,42,44,180,180)
        $g.DrawEllipse($track,47,49,170,170)
        $g.DrawArc($arc,42,44,180,180,[float]$script:angle,70)
    } finally { $arc.Dispose(); $track.Dispose() }
})
$status = Label '' $left 8 225 249 29 11 $true
$status.TextAlign = 'MiddleCenter'
$test = Button 'Test connection' $left 61 268 143 31
$null = Label 'Profile' $right 18 16 400 22 11 $true
$profiles = New-Object Windows.Forms.ComboBox
$profiles.DropDownStyle = 'DropDownList'
Place $profiles $right 18 45 421 28
$link = New-Object Windows.Forms.TextBox
$link.UseSystemPasswordChar = $true
$link.AccessibleName = 'Subscription URL or VLESS link'
$null = Label 'Subscription URL or VLESS link' $right 18 85 310 19 9
Place $link $right 18 108 303 28
$import = Button 'Import' $right 330 104 109 33
$null = Label 'Connection details' $right 18 155 400 26 12 $true
$fields = @{}
$i = 0
foreach ($name in @('Gateway','Exit IP','HTTPS latency','Session time')) {
    $line = 193 + 27 * $i
    $l = Label $name $right 18 $line 161 23
    $l.ForeColor = $colorMuted
    $fields[$name] = Label '—' $right 190 $line 252 23
    $fields[$name].AutoEllipsis = $true
    $i++
}
$detail = Label 'Paste a VLESS link or subscription to get started.' $form 24 413 742 59
$detail.ForeColor = $colorMuted

$tray = New-Object Windows.Forms.NotifyIcon
$tray.Icon = $form.Icon
$tray.Text = 'Lightning Proxy'
$tray.Visible = $true
$menu = New-Object Windows.Forms.ContextMenuStrip
$openItem = $menu.Items.Add('Open Lightning Proxy')
$toggleItem = $menu.Items.Add('Connect')
$quitItem = $menu.Items.Add('Stop Lightning Proxy')
$tray.ContextMenuStrip = $menu

$script:device = if ($null -ne $prefs) { [bool]$prefs.device } else { $false }
$script:quad = if ($null -ne $prefs) { [bool]$prefs.quad } else { $false }
function Render {
    $idle = $null -eq $script:pending
    $mode.Text = if ($script:device) { 'Device tunnel' } else { 'Local proxy' }
    $connect.Text = if ($script:active) { "ϟ`nDisconnect" } else { "ϟ`nConnect" }
    $status.Text = if (!$idle) { 'Connecting…' } elseif ($script:active) { 'Connected' } else { 'Disconnected' }
    $connect.Enabled = $idle -and ($script:active -or $profiles.SelectedIndex -ge 0)
    $connect.BackColor = if ($script:active) { [Drawing.Color]::FromArgb(199,244,117) } else { $colorCyan }
    $toggleItem.Text = if ($script:active) { 'Disconnect' } else { 'Connect' }
    $toggleItem.Enabled = $connect.Enabled
    $tray.Text = 'Lightning Proxy · ' + $status.Text
    $link.Enabled = $import.Enabled = $profiles.Enabled = $settings.Enabled = $idle -and !$script:active
    $test.Enabled = $idle -and $script:active
    $fields['Gateway'].Text = if ($script:info.host) { $script:info.host } else { '—' }
    $fields['Exit IP'].Text = if ($script:info.ip) { $script:info.ip } else { '—' }
    $fields['HTTPS latency'].Text = if ($null -ne $script:info.latency) { "$($script:info.latency) ms" } else { '—' }
    $fields['Session time'].Text = if ($script:connectedAt) { ([DateTime]::UtcNow - $script:connectedAt).ToString('hh\:mm\:ss') } else { '—' }
}
function Request($kind,$fields) {
    if ($script:pending -or $engine.HasExited) { return }
    $fields.action = $kind
    $script:action = $kind
    try {
        $inputStream.WriteLine(($fields | ConvertTo-Json -Compress))
        $script:pending = $engine.StandardOutput.ReadLineAsync()
    } catch { $detail.Text = 'The connection engine is not responding.' }
    Render
}
function SaveProfiles($text) {
    [IO.Directory]::CreateDirectory($storeDir) | Out-Null
    $bytes = [Security.Cryptography.ProtectedData]::Protect($utf8.GetBytes($text),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
    [IO.File]::WriteAllBytes($store,$bytes)
}
function Toggle {
    if ($script:pending) { return }
    if ($script:active) { $detail.Text = 'Disconnecting…'; Request 'stop' @{}; return }
    if ($profiles.SelectedIndex -lt 0) { return }
    if ($script:device -and !$admin) {
        $choice = [Windows.Forms.MessageBox]::Show($form,'Device Tunnel needs administrator approval. Reopen Lightning Proxy with elevated permissions for this session?','Device tunnel',[Windows.Forms.MessageBoxButtons]::YesNo)
        if ($choice -eq 'Yes') {
            try { Start-Process -FilePath $Launcher -ArgumentList ("--resume " + $profiles.SelectedIndex) -Verb RunAs; ExitApp } catch { $detail.Text = 'Windows approval was cancelled.' }
        }
        return
    }
    $detail.Text = 'Checking gateway and connection…'
    Request 'connect' @{index=$profiles.SelectedIndex;device=$script:device;quad=$script:quad}
}
function ExitApp {
    $script:quitting = $true
    if ($script:pending -and $script:action -eq 'connect') {
        $script:phase = ($script:phase + 1) % 24
        $pulse = [Math]::Sin($script:phase * [Math]::PI / 12)
        $connect.BackColor = [Drawing.Color]::FromArgb([int](125 + 27*$pulse),[int](198 + 28*$pulse),245)
    }
    if (!$script:pending) {
        if ($engine.HasExited) { $form.Close() } else { Request 'quit' @{} }
    }
}
$timer = New-Object Windows.Forms.Timer
$timer.Interval = 100
$script:angle = -90
$timer.Add_Tick({
    if ($motion -and $form.Visible -and ($script:active -or ($script:pending -and $script:action -eq 'connect'))) {
        $script:angle = ($script:angle + $(if ($script:active) { 5 } else { 20 })) % 360
        $left.Invalidate()
    }
    if (!$script:pending) {
        if ($engine.HasExited) { $script:active=$false; $detail.Text='The connection engine has stopped.'; Render; return }
        if ($script:active -and ([DateTime]::UtcNow-$script:lastStatus).TotalSeconds -ge 3) {
            $script:lastStatus=[DateTime]::UtcNow
            Request 'status' @{device=$script:device}
        }
        return
    }
    if (!$script:pending.IsCompleted) { return }
    $kind = $script:action
    try {
        $reply = $script:pending.GetAwaiter().GetResult() | ConvertFrom-Json
        if (!$reply) { throw 'No response.' }
        $wasActive = $script:active
        $script:active = [bool]$reply.active
        if (!$script:active) { $script:connectedAt=$null; $script:info=$null }
        if ($reply.error) { $detail.Text = $reply.error }
        else {
            switch ($kind) {
                { $_ -in 'import','restore' } {
                    $profiles.Items.Clear()
                    foreach ($name in $reply.profiles) { $profiles.Items.Add([string]$name) | Out-Null }
                    if ($profiles.Items.Count) { $profiles.SelectedIndex=0 }
                    $link.Clear()
                    $detail.Text = 'Profile loaded. You can connect now.'
                    if ($kind -eq 'import' -or !(Test-Path -LiteralPath $store)) {
                        try { SaveProfiles $reply.links } catch { $detail.Text='Profile loaded. Windows could not save it.' }
                    }
                }
                'connect' {
                    $script:info=$reply.info
                    $script:connectedAt=[DateTime]::UtcNow
                    $detail.Text=if($script:device){'Device tunnel is active.'}else{'HTTP 127.0.0.1:10809 · SOCKS5 127.0.0.1:10808'}
                }
                'test' {
                    $script:info=[pscustomobject]@{host=$script:info.host;ip=$reply.info.ip;latency=$reply.info.latency}
                    $detail.Text='HTTPS test passed.'
                }
                'stop' { $detail.Text='Disconnected.' }
                'status' { if ($wasActive -and !$script:active) { $detail.Text='The connection has stopped.'; $script:pending=$null; Request 'stop' @{}; return } }
            }
        }
    } catch { $detail.Text='The connection engine is not responding.'; $script:active=$false }
    $script:pending = $null
    if ($kind -eq 'quit') { $form.Close(); return }
    if ($script:quitting) { ExitApp; return }
    Render
    if ($kind -eq 'restore' -and $admin -and $ResumeIndex -ge 0 -and $ResumeIndex -lt $profiles.Items.Count) {
        $profiles.SelectedIndex = $ResumeIndex
        $ResumeIndex = -1
        Toggle
    }
})
$connect.Add_Click({Toggle})
$toggleItem.Add_Click({Toggle})
$import.Add_Click({if ($link.Text.Trim()) {Request 'import' @{input=$link.Text.Trim()}}})
$test.Add_Click({Request 'test' @{device=$script:device}})
$openItem.Add_Click({$form.Show(); $form.WindowState='Normal'; $form.Activate()})
$tray.Add_DoubleClick({$form.Show(); $form.WindowState='Normal'; $form.Activate()})
$quitItem.Add_Click({ExitApp})
$form.Add_FormClosing({
    if (!$script:quitting -and $_.CloseReason -eq 'UserClosing') { $_.Cancel=$true; $form.Hide() }
})
$settings.Add_Click({
    $dialog=New-Object Windows.Forms.Form
    $dialog.Text='Settings'
    $dialog.ClientSize=New-Object Drawing.Size(420,166)
    $dialog.StartPosition='CenterParent'
    $dialog.FormBorderStyle='FixedDialog'
    $dialog.MaximizeBox=$false
    $dialog.MinimizeBox=$false
    $device=New-Object Windows.Forms.CheckBox
    $device.Text='Device tunnel (administrator approval required)'
    $device.Checked=$script:device
    Place $device $dialog 20 20 380 28
    $quad=New-Object Windows.Forms.CheckBox
    $quad.Text='Use Quad9 DNS for the device tunnel'
    $quad.Checked=$script:quad
    Place $quad $dialog 20 55 380 28
    $save=Button 'Save' $dialog 277 105 120 32
    $save.DialogResult='OK'
    $dialog.AcceptButton=$save
    if ($dialog.ShowDialog($form) -eq 'OK') {
        $script:device=$device.Checked
        $script:quad=$quad.Checked
        try {
            [IO.Directory]::CreateDirectory($storeDir) | Out-Null
            @{device=$script:device;quad=$script:quad} | ConvertTo-Json | Set-Content -LiteralPath $pref
        } catch { $detail.Text='Windows could not save the settings.' }
        Render
    }
    $dialog.Dispose()
})
Render
$timer.Start()
$loadPath = if (Test-Path -LiteralPath $store) { $store } else { Join-Path $env:LOCALAPPDATA 'Cheesy Proxy/profiles.dat' }
if (Test-Path -LiteralPath $loadPath) {
    try {
        $plain=[Security.Cryptography.ProtectedData]::Unprotect([IO.File]::ReadAllBytes($loadPath),$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
        Request 'restore' @{input=$utf8.GetString($plain)}
    } catch { $detail.Text='Saved profiles could not be loaded.' }
}
try { [Windows.Forms.Application]::Run($form) }
finally {
    $timer.Stop()
    $tray.Dispose()
    $inputStream.Dispose()
    $engine.WaitForExit(35000) | Out-Null
}
