#import <Foundation/Foundation.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <unistd.h>
#include <signal.h>

int main(int argc,const char **argv){@autoreleasepool{
 if(geteuid()!=0||argc!=1)return 64;
 char wire[4096];if(!fgets(wire,sizeof(wire),stdin))return 65;
 NSData *input=[NSData dataWithBytes:wire length:strlen(wire)];
 id value=[NSJSONSerialization JSONObjectWithData:input options:0 error:NULL];
 if(![value isKindOfClass:NSDictionary.class]||![value[@"ip"] isKindOfClass:NSString.class]||
    ![value[@"quad"] isKindOfClass:NSNumber.class])return 65;
 NSString *ip=value[@"ip"];struct in6_addr address;
 BOOL ipv4=inet_pton(AF_INET,ip.UTF8String,&address)==1;
 if(!ipv4&&inet_pton(AF_INET6,ip.UTF8String,&address)!=1)return 65;
 if([ip isEqual:@"0.0.0.0"]||[ip isEqual:@"::"])return 65;
 BOOL quad=[value[@"quad"] boolValue];
 NSDictionary *config=@{@"log":@{@"level":@"error"},
  @"dns":@{@"servers":@[@{@"type":@"https",@"tag":@"remote",@"server":quad?@"9.9.9.9":@"1.1.1.1",
   @"tls":@{@"enabled":@YES,@"server_name":quad?@"dns.quad9.net":@"cloudflare-dns.com"},@"detour":@"proxy"}],@"final":@"remote"},
  @"inbounds":@[@{@"type":@"tun",@"interface_name":@"utun83",@"address":@[@"172.31.255.1/30",@"fd7a:91f3:87b1::1/126"],
    @"mtu":@1400,@"auto_route":@YES,@"stack":@"mixed",@"route_exclude_address":@[[ip stringByAppendingString:ipv4?@"/32":@"/128"]]}],
  @"outbounds":@[@{@"type":@"socks",@"tag":@"proxy",@"server":@"127.0.0.1",@"server_port":@10808,@"version":@"5"}],
  @"route":@{@"final":@"proxy",@"rules":@[@{@"port":@53,@"action":@"hijack-dns"}]}};
 char dir[]="/private/var/tmp/lightning-router.XXXXXX";if(!mkdtemp(dir))return 1;
 NSString *path=[NSString stringWithUTF8String:dir];
 NSString *filename=[path stringByAppendingPathComponent:@"config.json"];
 NSData *json=[NSJSONSerialization dataWithJSONObject:config options:0 error:NULL];
 int status=1;
 if([json writeToFile:filename atomically:YES]){
  NSTask *task=[NSTask new];task.executableURL=[NSURL fileURLWithPath:@"/opt/lightning-proxy/sing-box"];
  task.arguments=@[@"run",@"-D",path,@"-c",filename];task.currentDirectoryURL=[NSURL fileURLWithPath:path];
  task.environment=@{@"PATH":@"/usr/bin:/bin:/usr/sbin:/sbin",@"HOME":@"/var/empty"};
  task.standardInput=NSFileHandle.fileHandleWithNullDevice;
  if([task launchAndReturnError:NULL]){
   dispatch_semaphore_t closed=dispatch_semaphore_create(0);
   dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0),^{char buffer[128];while(fread(buffer,1,sizeof(buffer),stdin)>0){} dispatch_semaphore_signal(closed);});
   while(task.running&&dispatch_semaphore_wait(closed,dispatch_time(DISPATCH_TIME_NOW,200*NSEC_PER_MSEC))){}
   if(task.running){
    [task terminate];for(int i=0;i<20&&task.running;i++)[NSThread sleepForTimeInterval:.1];
    if(task.running)kill(task.processIdentifier,SIGKILL);
   }
   [task waitUntilExit];status=task.terminationStatus;
  }
 }
 [NSFileManager.defaultManager removeItemAtPath:path error:NULL];
 return status;
}}
