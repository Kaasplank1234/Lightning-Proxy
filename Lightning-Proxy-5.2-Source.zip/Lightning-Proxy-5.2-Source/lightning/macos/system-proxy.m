#import <Foundation/Foundation.h>
#import <SystemConfiguration/SystemConfiguration.h>
#include <unistd.h>
#include <sys/file.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>

static NSString *const Journal = @"/opt/lightning-proxy/proxy-backup.plist";

static NSDictionary *settings(void) {
    return @{@"HTTPEnable":@1,@"HTTPProxy":@"127.0.0.1",@"HTTPPort":@10809,
      @"HTTPSEnable":@1,@"HTTPSProxy":@"127.0.0.1",@"HTTPSPort":@10809,
      @"SOCKSEnable":@1,@"SOCKSProxy":@"127.0.0.1",@"SOCKSPort":@10808,
      @"ProxyAutoConfigEnable":@0,@"ProxyAutoDiscoveryEnable":@0};
}

static BOOL apply(BOOL restoring) {
    NSDictionary *saved = restoring ? [NSDictionary dictionaryWithContentsOfFile:Journal] : nil;
    if (restoring && !saved) return ![NSFileManager.defaultManager fileExistsAtPath:Journal];
    SCPreferencesRef prefs=SCPreferencesCreate(NULL,CFSTR("Lightning Proxy"),NULL);
    if (!prefs) return NO;
    if (!SCPreferencesLock(prefs,false)) {CFRelease(prefs);return NO;}
    NSMutableDictionary *backup=[NSMutableDictionary dictionary];
    NSDictionary *values=settings();
    BOOL ok=YES;
    SCNetworkSetRef current=SCNetworkSetCopyCurrent(prefs);
    NSArray *services=restoring ? nil : CFBridgingRelease(current ? SCNetworkSetCopyServices(current) : NULL);
    if(current) CFRelease(current);
    NSArray *items=restoring ? saved.allKeys : services;
    for(id item in items) {
        SCNetworkServiceRef service=restoring ? SCNetworkServiceCopy(prefs,(__bridge CFStringRef)item) : (__bridge SCNetworkServiceRef)item;
        if(!service) continue;
        SCNetworkProtocolRef proto=(restoring || SCNetworkServiceGetEnabled(service)) ?
           SCNetworkServiceCopyProtocol(service,kSCNetworkProtocolTypeProxies) : NULL;
        if(!proto){if(restoring)CFRelease(service);continue;}
        NSString *key=(__bridge NSString *)SCNetworkServiceGetServiceID(service);
        NSDictionary *original=(__bridge NSDictionary *)SCNetworkProtocolGetConfiguration(proto);
        NSMutableDictionary *next=[original mutableCopy] ?: [NSMutableDictionary dictionary];
        if(restoring){
            NSDictionary *record=saved[key], *prior=record[@"values"];
            BOOL matches=[original[@"HTTPProxy"] isEqual:values[@"HTTPProxy"]] && [original[@"HTTPPort"] isEqual:values[@"HTTPPort"]];
            for(NSString *field in values) if([next[field] isEqual:values[field]]) next[field]=prior[field];
            ok=SCNetworkProtocolSetConfiguration(proto,next.count || [record[@"hadConfig"] boolValue] ? (__bridge CFDictionaryRef)next : NULL);
            if(ok && matches) ok=SCNetworkProtocolSetEnabled(proto,[record[@"enabled"] boolValue]);
        } else {
            backup[key]=@{@"values":original ?: @{},@"hadConfig":@(original!=nil),@"enabled":@(SCNetworkProtocolGetEnabled(proto))};
            [next addEntriesFromDictionary:values];
            ok=SCNetworkProtocolSetConfiguration(proto,(__bridge CFDictionaryRef)next) && SCNetworkProtocolSetEnabled(proto,true);
        }
        CFRelease(proto);
        if(restoring)CFRelease(service);
        if(!ok)break;
    }
    if(ok && !restoring) ok=backup.count && [backup writeToFile:Journal atomically:YES];
    if(ok) ok=SCPreferencesCommitChanges(prefs) && SCPreferencesApplyChanges(prefs);
    SCPreferencesUnlock(prefs);CFRelease(prefs);
    if(ok && restoring) ok=[NSFileManager.defaultManager removeItemAtPath:Journal error:NULL];
    return ok;
}

int main(int argc,const char **argv){@autoreleasepool{
    if(geteuid()!=0 || argc!=1)return 64;
    umask(077);
    int fd=open("/opt/lightning-proxy/proxy.lock",O_CREAT|O_RDWR,0600);
    if(fd<0 || flock(fd,LOCK_EX|LOCK_NB)!=0)return 1;
    if(!apply(YES) || !apply(NO)){apply(YES);return 1;}
    puts("ready");fflush(stdout);
    char buffer[64];while(read(STDIN_FILENO,buffer,sizeof(buffer))>0){}
    int status=apply(YES)?0:1;
    close(fd);
    return status;
}}
