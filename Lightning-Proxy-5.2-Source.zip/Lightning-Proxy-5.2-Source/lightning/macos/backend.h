#import <Foundation/Foundation.h>
@interface ProxyBackend : NSObject
- (NSDictionary *)request:(NSDictionary *)request;
- (void)stop;
@end
