#!/bin/sh
set -eu
[ "$(/usr/bin/id -u)" -eq 0 ] && [ "$#" -eq 2 ] || exit 64
uid=$1
case "$uid" in ''|*[!0-9]*) exit 64;; esac
[ "$uid" -ge 501 ] || exit 64
resources=$2
dir=/opt/lightning-proxy
[ ! -L "$dir" ] || exit 65
/usr/bin/install -d -m 0755 -o root -g wheel "$dir"
for name in tunnel-router sing-box system-proxy; do
    tmp=$(/usr/bin/mktemp "$dir/install.XXXXXX")
    /usr/bin/install -m 0755 -o root -g wheel "$resources/$name" "$tmp"
    /bin/mv -f "$tmp" "$dir/$name"
done
tmp=$(/usr/bin/mktemp "$dir/sudoers.XXXXXX")
trap '/bin/rm -f "$tmp"' EXIT
printf '#%s ALL=(root) NOPASSWD: /opt/lightning-proxy/tunnel-router "", /opt/lightning-proxy/system-proxy ""\n' "$uid" > "$tmp"
/usr/sbin/visudo -cf "$tmp"
/bin/chmod 0440 "$tmp"
/bin/mv -f "$tmp" "/etc/sudoers.d/lightning-proxy-$uid"
