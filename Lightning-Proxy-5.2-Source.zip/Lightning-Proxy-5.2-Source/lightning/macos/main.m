#import <AppKit/AppKit.h>
#import <QuartzCore/QuartzCore.h>
#import "backend.h"
#include <signal.h>
#include <stdio.h>
#include <unistd.h>

static NSColor *rgb(unsigned c){return [NSColor colorWithSRGBRed:(c>>16)/255.0 green:((c>>8)&255)/255.0 blue:(c&255)/255.0 alpha:1];}
static void put(NSView *parent, NSView *view, CGFloat x,CGFloat y,CGFloat w,CGFloat h){view.frame=NSMakeRect(x,y,w,h);[parent addSubview:view];}
static NSTextField *label(NSView *parent,NSString *title, CGFloat size, NSFontWeight weight, NSColor *color,NSRect frame){
 NSTextField *field=[NSTextField labelWithString:title];field.font=[NSFont systemFontOfSize:size weight:weight];field.textColor=color;
 put(parent,field,frame.origin.x,frame.origin.y,frame.size.width,frame.size.height);return field;
}
static NSView *card(NSView *parent,NSRect frame){
 NSView *v=[[NSView alloc]initWithFrame:frame];v.wantsLayer=YES;v.layer.cornerRadius=18;
 v.layer.backgroundColor=rgb(0x151b2c).CGColor;v.layer.borderColor=rgb(0x2b344d).CGColor;v.layer.borderWidth=1;[parent addSubview:v];return v;
}
@interface PowerButton:NSButton
@property BOOL online;
@end
@implementation PowerButton
- (void)drawRect:(NSRect)dirty {
 NSRect r=NSInsetRect(self.bounds,4,4);
 NSBezierPath *oval=[NSBezierPath bezierPathWithOvalInRect:r];
 NSColor *first=self.online?rgb(0xf2ffa4):rgb(0xf7ffb3), *second=self.online?rgb(0x9de458):rgb(0xcbe95c);
 if(!self.enabled){first=[first blendedColorWithFraction:.66 ofColor:rgb(0x232944)];second=[second blendedColorWithFraction:.66 ofColor:rgb(0x232944)];}
 if(self.highlighted){r=NSInsetRect(r,3,3);oval=[NSBezierPath bezierPathWithOvalInRect:r];}
 [[[NSGradient alloc]initWithStartingColor:first endingColor:second] drawInBezierPath:oval angle:-48];
 if(self.window.firstResponder==self){[rgb(0xecff97) setStroke];NSBezierPath *focus=[NSBezierPath bezierPathWithOvalInRect:NSInsetRect(r,-3,-3)];focus.lineWidth=1.5;[focus stroke];}
 NSPoint center=NSMakePoint(NSMidX(r),NSMidY(r)+11);
 NSBezierPath *bolt=[NSBezierPath bezierPath];
 [bolt moveToPoint:NSMakePoint(center.x+5,center.y+26)];
 [bolt lineToPoint:NSMakePoint(center.x-16,center.y-1)];
 [bolt lineToPoint:NSMakePoint(center.x-4,center.y-1)];
 [bolt lineToPoint:NSMakePoint(center.x-8,center.y-21)];
 [bolt lineToPoint:NSMakePoint(center.x+16,center.y+7)];
 [bolt lineToPoint:NSMakePoint(center.x+3,center.y+7)];
 [bolt closePath];[rgb(0x121832) setFill];[bolt fill];
 NSDictionary *style=@{NSFontAttributeName:[NSFont systemFontOfSize:13 weight:NSFontWeightBold],NSForegroundColorAttributeName:rgb(0x121832)};
 NSSize size=[self.title sizeWithAttributes:style];
 [self.title drawAtPoint:NSMakePoint(NSMidX(r)-size.width/2,NSMidY(r)-31) withAttributes:style];
}
@end

@interface LightningApp:NSObject <NSApplicationDelegate,NSWindowDelegate>
@end
@implementation LightningApp {
 NSWindow *_window;
 NSStatusItem *_tray;
 NSMenuItem *_trayToggle;
 ProxyBackend *_backend;
 dispatch_queue_t _worker;
 NSString *_pending;
 NSTimer *_timer;
 PowerButton *_power;
 CAShapeLayer *_orbit,*_halo;
 NSButton *_import,*_test,*_settings;
 NSPopUpButton *_profiles;
 NSSecureTextField *_link;
 NSTextField *_status,*_modeLabel,*_message,*_gateway,*_ip,*_latency,*_elapsed;
 NSArray *_names;
 NSMutableDictionary *_info;
 BOOL _active,_authorized,_quad,_motion,_quitting;
 NSInteger _mode,_animationState;
 NSDate *_since;
 NSUInteger _ticks;
}
- (void)applicationDidFinishLaunching:(NSNotification *)note {
 [NSUserDefaults.standardUserDefaults registerDefaults:@{@"ConnectionMode":@0,@"AnimationsEnabled":@YES,@"Quad9DNS":@NO}];
 _mode=[NSUserDefaults.standardUserDefaults integerForKey:@"ConnectionMode"];
 if(_mode<0||_mode>2)_mode=0;
 _motion=[NSUserDefaults.standardUserDefaults boolForKey:@"AnimationsEnabled"];
 _quad=[NSUserDefaults.standardUserDefaults boolForKey:@"Quad9DNS"];
 _animationState=-1;_worker=dispatch_queue_create("lightning.io",DISPATCH_QUEUE_SERIAL);
 [self menus];[self createWindow];
 _backend=[ProxyBackend new];[self request:@"load" fields:nil];
 _timer=[NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(tick:) userInfo:nil repeats:YES];
}
- (void)menus {
 _tray=[NSStatusBar.systemStatusBar statusItemWithLength:NSVariableStatusItemLength];
 NSMenu *menu=[NSMenu new];
 _trayToggle=[menu addItemWithTitle:@"Connect" action:@selector(toggle:) keyEquivalent:@""];_trayToggle.target=self;
 [menu addItemWithTitle:@"Open Lightning Proxy" action:@selector(show:) keyEquivalent:@""].target=self;
 [menu addItem:NSMenuItem.separatorItem];
 [menu addItemWithTitle:@"Quit Lightning Proxy" action:@selector(terminate:) keyEquivalent:@""].target=NSApp;
 _tray.menu=menu;
 NSMenu *bar=[NSMenu new];
 NSMenuItem *app=[NSMenuItem new];app.submenu=[[NSMenu alloc]initWithTitle:@"Lightning Proxy"];
 [app.submenu addItemWithTitle:@"Settings…" action:@selector(showSettings:) keyEquivalent:@","].target=self;
 [app.submenu addItemWithTitle:@"Quit Lightning Proxy" action:@selector(terminate:) keyEquivalent:@"q"];
 [bar addItem:app];
 NSMenuItem *edit=[NSMenuItem new];edit.submenu=[[NSMenu alloc]initWithTitle:@"Edit"];
 [edit.submenu addItemWithTitle:@"Cut" action:@selector(cut:) keyEquivalent:@"x"];
 [edit.submenu addItemWithTitle:@"Copy" action:@selector(copy:) keyEquivalent:@"c"];
 [edit.submenu addItemWithTitle:@"Paste" action:@selector(paste:) keyEquivalent:@"v"];
 [edit.submenu addItemWithTitle:@"Select All" action:@selector(selectAll:) keyEquivalent:@"a"];
 [bar addItem:edit];NSApp.mainMenu=bar;
}
- (void)createWindow {
 _window=[[NSWindow alloc]initWithContentRect:NSMakeRect(0,0,790,492)
  styleMask:NSWindowStyleMaskTitled|NSWindowStyleMaskClosable|NSWindowStyleMaskMiniaturizable backing:NSBackingStoreBuffered defer:NO];
 _window.title=@"Lightning Proxy";_window.delegate=self;
 _window.appearance=[NSAppearance appearanceNamed:NSAppearanceNameDarkAqua];
 NSView *root=_window.contentView;root.wantsLayer=YES;
 CAGradientLayer *bg=[CAGradientLayer layer];bg.frame=root.bounds;
 bg.colors=@[(__bridge id)rgb(0x19213c).CGColor,(__bridge id)rgb(0x0b101e).CGColor,(__bridge id)rgb(0x0e1424).CGColor];
 bg.startPoint=CGPointMake(0,1);bg.endPoint=CGPointMake(1,0);[root.layer insertSublayer:bg atIndex:0];
 NSColor *ink=rgb(0xeff1ff),*muted=rgb(0xaab6d2);
 NSView *brand=card(root,NSMakeRect(24,427,40,40));brand.layer.cornerRadius=12;
 brand.layer.backgroundColor=rgb(0xe6fc8d).CGColor;
 NSTextField *mark=label(brand,@"ϟ",25,NSFontWeightHeavy,rgb(0x121832),NSMakeRect(0,3,40,33));mark.alignment=NSTextAlignmentCenter;
 label(root,@"Lightning Proxy",29,NSFontWeightBold,ink,NSMakeRect(77,430,470,38));
 _settings=[NSButton buttonWithTitle:@"Settings…" target:self action:@selector(showSettings:)];
 put(root,_settings,638,434,128,27);
 NSView *hero=card(root,NSMakeRect(24,96,272,309));
 _modeLabel=label(hero,@"System Proxy",13,NSFontWeightSemibold,rgb(0xc8d4f4),NSMakeRect(12,273,248,21));
 _modeLabel.alignment=NSTextAlignmentCenter;
 NSView *rings=[[NSView alloc]initWithFrame:NSMakeRect(40,73,192,192)];rings.wantsLayer=YES;[hero addSubview:rings];
 for(NSUInteger i=0;i<3;i++){
  CAShapeLayer *ring=[CAShapeLayer layer];ring.frame=rings.bounds;ring.fillColor=NSColor.clearColor.CGColor;
  CGRect rect=CGRectInset(NSRectToCGRect(rings.bounds),7+5*i,7+5*i);
  CGPathRef path=CGPathCreateWithEllipseInRect(rect,NULL);ring.path=path;CGPathRelease(path);
  ring.lineWidth=i==1?2.5:1;ring.strokeColor=rgb(0x475275).CGColor;[rings.layer addSublayer:ring];
  if(i==0){_halo=ring;ring.lineWidth=1.5;}
  if(i==1){_orbit=ring;ring.strokeEnd=.21;ring.lineCap=kCALineCapRound;
   ring.shadowColor=rgb(0xc8f47a).CGColor;ring.shadowRadius=5;ring.shadowOpacity=.65;ring.shadowOffset=CGSizeZero;
  }
 }
 _power=[[PowerButton alloc]initWithFrame:NSZeroRect];_power.bordered=NO;_power.title=@"Connect";_power.target=self;_power.action=@selector(toggle:);
 put(hero,_power,65,98,142,142);
 _status=label(hero,@"Disconnected",15,NSFontWeightSemibold,ink,NSMakeRect(8,51,256,22));_status.alignment=NSTextAlignmentCenter;
 _test=[NSButton buttonWithTitle:@"Test Connection" target:self action:@selector(test:)];
 put(hero,_test,66,13,140,28);
 NSView *details=card(root,NSMakeRect(313,96,453,309));
 label(details,@"Profile",14,NSFontWeightSemibold,ink,NSMakeRect(18,269,410,22));
 _profiles=[[NSPopUpButton alloc]initWithFrame:NSZeroRect pullsDown:NO];[_profiles addItemWithTitle:@"No profile imported"];
 put(details,_profiles,14,234,425,29);
 _link=[NSSecureTextField new];_link.placeholderString=@"Subscription URL or VLESS link";_link.target=self;_link.action=@selector(import:);
 put(details,_link,18,192,309,25);
 _import=[NSButton buttonWithTitle:@"Import" target:self action:@selector(import:)];put(details,_import,334,190,103,28);
 label(details,@"Connection Details",14,NSFontWeightSemibold,ink,NSMakeRect(18,151,410,22));
 NSArray *keys=@[@"Gateway",@"Exit IP",@"HTTPS Latency",@"Session Time"];
 NSMutableArray *fields=[NSMutableArray array];
 for(NSUInteger i=0;i<keys.count;i++){
  CGFloat y=119-28*i;
  if(i>0){
   NSView *line=[[NSView alloc]initWithFrame:NSMakeRect(18,y+22,414,1)];
   line.wantsLayer=YES;line.layer.backgroundColor=rgb(0x283148).CGColor;[details addSubview:line];
  }
  label(details,keys[i],12,NSFontWeightMedium,muted,NSMakeRect(18,y,140,18));
  NSTextField *field=label(details,@"—",12,NSFontWeightMedium,ink,NSMakeRect(163,y,265,18));
  field.font=[NSFont monospacedDigitSystemFontOfSize:12 weight:NSFontWeightMedium];field.lineBreakMode=NSLineBreakByTruncatingMiddle;field.selectable=YES;
  [fields addObject:field];
 }
 _gateway=fields[0];_ip=fields[1];_latency=fields[2];_elapsed=fields[3];
 _message=[NSTextField wrappingLabelWithString:@"Paste a profile to get started."];
 _message.textColor=muted;_message.font=[NSFont systemFontOfSize:13];_message.maximumNumberOfLines=3;_message.selectable=YES;
 put(root,_message,27,20,733,53);
 [_window center];[self render];[self show:nil];
}
- (void)show:(id)sender {[_window makeKeyAndOrderFront:nil];[NSApp activateIgnoringOtherApps:YES];}
- (BOOL)applicationShouldHandleReopen:(NSApplication *)app hasVisibleWindows:(BOOL)visible{[self show:nil];return YES;}
- (BOOL)windowShouldClose:(NSWindow *)window{[window orderOut:nil];return NO;}
- (void)animate:(BOOL)busy {
 BOOL motion=_motion&&!NSWorkspace.sharedWorkspace.accessibilityDisplayShouldReduceMotion&&_window.isVisible;
 NSInteger state=(busy?1:_active?2:0)+(motion?4:0);
 if(_animationState==state)return;
 _animationState=state;[_orbit removeAllAnimations];[_halo removeAllAnimations];
 _orbit.strokeColor=(_active?rgb(0xdfff8c):rgb(0xd7ff71)).CGColor;
 _halo.strokeColor=(_active?rgb(0xb7ed62):rgb(0x435171)).CGColor;
 if(!motion||(!busy&&!_active))return;
 CABasicAnimation *spin=[CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
 spin.byValue=@(2*M_PI);spin.repeatCount=HUGE_VALF;spin.duration=busy?1.25:7;
 [_orbit addAnimation:spin forKey:@"rotation"];
 if(_active&&!busy){
  CABasicAnimation *pulse=[CABasicAnimation animationWithKeyPath:@"opacity"];
  pulse.fromValue=@.25;pulse.toValue=@1;pulse.duration=1.6;pulse.autoreverses=YES;pulse.repeatCount=HUGE_VALF;
  [_halo addAnimation:pulse forKey:@"pulse"];
  CABasicAnimation *expand=[CABasicAnimation animationWithKeyPath:@"transform.scale"];
  expand.fromValue=@.98;expand.toValue=@1.06;expand.duration=1.6;
  expand.autoreverses=YES;expand.repeatCount=HUGE_VALF;
  [_halo addAnimation:expand forKey:@"expand"];
 }
}
- (void)render {
 BOOL busy=_pending && ![_pending isEqual:@"status"];
 BOOL editable=!busy&&!_active;
 _modeLabel.stringValue=@[@"System Proxy",@"Device Tunnel · TUN",@"Local Proxy"][_mode];
 _status.stringValue=busy?@"Working…":_active?@"Connected":@"Disconnected";
 _status.textColor=_active?rgb(0xdfff8c):rgb(0xf0f2ff);
 _power.title=_active?@"Disconnect":@"Connect";_power.online=_active;
 _power.enabled=!busy&&(_active||_names.count>0);[_power setNeedsDisplay:YES];
 _trayToggle.title=_power.title;_trayToggle.enabled=_power.enabled;
 _tray.button.title=_active?@"ϟ ●":@"ϟ";_tray.button.toolTip=[@"Lightning Proxy · " stringByAppendingString:_status.stringValue];
 _profiles.enabled=editable&&_names.count;_import.enabled=_link.enabled=editable;_settings.enabled=editable;_test.enabled=_active&&!busy;
 _gateway.stringValue=_info[@"host"]?:@"—";_ip.stringValue=_info[@"ip"]?:@"—";
 _latency.stringValue=_info[@"latency"]?[NSString stringWithFormat:@"%@ ms",_info[@"latency"]]:@"—";
 NSInteger elapsed=_since?(NSInteger)-[_since timeIntervalSinceNow]:0;
 _elapsed.stringValue=_since?[NSString stringWithFormat:@"%02ld:%02ld:%02ld",(long)elapsed/3600,(long)(elapsed/60)%60,(long)elapsed%60]:@"—";
 [self animate:busy];
}
- (void)request:(NSString *)action fields:(NSDictionary *)fields {
 if(_pending||_quitting)return;
 NSMutableDictionary *data=[@{@"action":action,@"device":@(_mode==1),@"quad":@(_quad),@"system":@(_mode==0)} mutableCopy];
 [data addEntriesFromDictionary:fields?:@{}];
 if([data[@"input"] length]>1000000){_message.stringValue=@"The profile input is too large.";return;}
 _pending=action;[self render];
 dispatch_async(_worker,^{@autoreleasepool{
  NSDictionary *response=[self->_backend request:data];
  dispatch_async(dispatch_get_main_queue(),^{[self reply:response];});
 }});
}
- (void)reply:(NSDictionary *)reply {
 NSString *action=_pending;_pending=nil;
 if(reply[@"tunnelReady"])_authorized=[reply[@"tunnelReady"] boolValue];
 if([reply[@"profiles"] isKindOfClass:NSArray.class]){
  _names=reply[@"profiles"];[_profiles removeAllItems];
  for(NSUInteger i=0;i<_names.count;i++){
   NSString *name=_names[i];
   if([_profiles itemWithTitle:name])name=[name stringByAppendingFormat:@" (%lu)",(unsigned long)i+1];
   [_profiles addItemWithTitle:name];
  }
  if(!_names.count)[_profiles addItemWithTitle:@"No profile imported"];
  if([action isEqual:@"import"]){_link.stringValue=@"";_message.stringValue=reply[@"warning"]?:@"Profile imported. Select Connect."; }
  else if([action isEqual:@"load"]&&_names.count)_message.stringValue=@"Saved profile loaded. Select Connect.";
 }
 if([reply[@"error"] hasPrefix:@"Network access is required."])_authorized=NO;
 BOOL wasActive=_active;
 _active=[reply[@"active"] boolValue];
 if(!_active){_info=nil;_since=nil;}
 if(reply[@"error"])_message.stringValue=reply[@"error"];
 else if([action isEqual:@"connect"]&&_active){
  _info=[reply[@"info"] mutableCopy];_since=[NSDate date];
  _message.stringValue=@[@"System proxy applied. Apps using macOS proxy settings are connected.",
   @"Device tunnel is active. TCP and UDP traffic uses the tunnel.",
   @"Local proxy is active · SOCKS5 127.0.0.1:10808 · HTTP 127.0.0.1:10809"][_mode];
 }else if([action isEqual:@"test"]&&_active){
  [_info addEntriesFromDictionary:reply[@"info"]?:@{}];_message.stringValue=@"The HTTPS connection test passed.";
 }else if([action isEqual:@"stop"])_message.stringValue=@"Disconnected.";
 if(wasActive&&!_active&&[action isEqual:@"status"]){[self request:@"stop" fields:nil];}
 [self render];
}
- (void)tick:(NSTimer *)timer {
 [self render];if(_active&&++_ticks%4==0)[self request:@"status" fields:nil];
}
- (void)import:(id)sender {
 NSString *link=[_link.stringValue stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
 if(!link.length){_message.stringValue=@"Paste a subscription URL or VLESS link.";return;}
 _message.stringValue=@"Importing profile…";[self request:@"import" fields:@{@"input":link}];
}
- (void)test:(id)sender{_message.stringValue=@"Testing the connection…";[self request:@"test" fields:nil];}
- (void)toggle:(id)sender {
 if(_pending)return;
 if(_active){_message.stringValue=@"Disconnecting…";[self request:@"stop" fields:nil];return;}
 if(!_names.count){[self show:nil];_message.stringValue=@"Import a profile first.";return;}
 if(_mode!=2&&!_authorized){[self enableNetwork];return;}
 [self connect];
}
- (void)connect {
 if(_profiles.indexOfSelectedItem<0)return;
 _message.stringValue=@"Starting Xray and checking the gateway…";
 [self request:@"connect" fields:@{@"index":@(_profiles.indexOfSelectedItem)}];
}
- (void)enableNetwork {
 [self show:nil];if(_window.attachedSheet)return;
 NSAlert *alert=[NSAlert new];
 alert.messageText=@"Enable system networking";
 alert.informativeText=@"Approve the one-time macOS administrator prompt to enable System Proxy and Device Tunnel. This installs dedicated networking helpers. You can then reconnect without entering your password again.";
 [alert addButtonWithTitle:@"Enable and Connect"];[alert addButtonWithTitle:@"Cancel"];
 [alert beginSheetModalForWindow:_window completionHandler:^(NSModalResponse result){
  if(result!=NSAlertFirstButtonReturn)return;
  self->_pending=@"setup";self->_message.stringValue=@"Waiting for macOS authorization…";[self render];
  dispatch_async(self->_worker,^{
   NSBundle *b=NSBundle.mainBundle;
   NSString *script=[b pathForResource:@"install-helper" ofType:@"sh"];
   NSString *command=@"on run argv\nset commandText to \"/bin/sh \" & quoted form of (item 1 of argv) & \" \" & quoted form of (item 2 of argv) & \" \" & quoted form of (item 3 of argv)\ndo shell script commandText with administrator privileges\nend run";
   NSTask *task=[NSTask new];task.executableURL=[NSURL fileURLWithPath:@"/usr/bin/osascript"];
   task.arguments=@[@"-e",command,script,[NSString stringWithFormat:@"%u",(unsigned)getuid()],b.resourcePath];
   task.standardOutput=NSFileHandle.fileHandleWithNullDevice;
   task.standardError=NSFileHandle.fileHandleWithNullDevice;
   BOOL ok=[task launchAndReturnError:NULL];
   if(ok){[task waitUntilExit];ok=task.terminationStatus==0;}
   dispatch_async(dispatch_get_main_queue(),^{
    self->_pending=nil;self->_authorized=ok;
    self->_message.stringValue=ok?@"Network access enabled.":@"Network access could not be enabled. Approve the administrator prompt or choose Local Proxy.";
    [self render];if(ok)[self connect];
   });
  });
 }];
}
- (void)showSettings:(id)sender {
 if(_active||_pending||_window.attachedSheet)return;
 [self show:nil];
 NSAlert *alert=[NSAlert new];alert.messageText=@"Connection Settings";
 alert.informativeText=@"System Proxy configures macOS automatically. Device Tunnel also routes apps that ignore system proxy settings. Local Proxy provides SOCKS5 and HTTP on localhost.";
 [alert addButtonWithTitle:@"Save"];[alert addButtonWithTitle:@"Cancel"];
 NSView *form=[[NSView alloc]initWithFrame:NSMakeRect(0,0,390,105)];
 NSPopUpButton *mode=[[NSPopUpButton alloc]initWithFrame:NSZeroRect pullsDown:NO];
 [mode addItemsWithTitles:@[@"System Proxy",@"Device Tunnel (TUN)",@"Local Proxy"]];
 [mode selectItemAtIndex:_mode];put(form,mode,0,72,390,28);
 NSButton *dns=[NSButton checkboxWithTitle:@"Use Quad9 DNS in Device Tunnel" target:nil action:NULL];dns.state=_quad?1:0;put(form,dns,4,41,385,22);
 NSButton *animations=[NSButton checkboxWithTitle:@"Show connection animations" target:nil action:NULL];animations.state=_motion?1:0;put(form,animations,4,10,385,22);
 alert.accessoryView=form;
 [alert beginSheetModalForWindow:_window completionHandler:^(NSModalResponse result){
  if(result!=NSAlertFirstButtonReturn)return;
  self->_mode=mode.indexOfSelectedItem;self->_quad=dns.state==1;self->_motion=animations.state==1;
  [NSUserDefaults.standardUserDefaults setInteger:self->_mode forKey:@"ConnectionMode"];
  [NSUserDefaults.standardUserDefaults setBool:self->_quad forKey:@"Quad9DNS"];
  [NSUserDefaults.standardUserDefaults setBool:self->_motion forKey:@"AnimationsEnabled"];
  [self render];
 }];
}
- (NSApplicationTerminateReply)applicationShouldTerminate:(NSApplication *)app {
 if(!_backend)return NSTerminateNow;
 if([_pending isEqual:@"setup"])return NSTerminateCancel;
 _quitting=YES;
 dispatch_async(_worker,^{
  [self->_backend stop];
  dispatch_async(dispatch_get_main_queue(),^{[NSApp replyToApplicationShouldTerminate:YES];});
 });
 return NSTerminateLater;
}
@end
int main(void){@autoreleasepool{
 signal(SIGPIPE,SIG_IGN);NSApplication *app=NSApplication.sharedApplication;
 __attribute__((objc_precise_lifetime)) LightningApp *delegate=[LightningApp new];
 app.delegate=delegate;[app setActivationPolicy:NSApplicationActivationPolicyRegular];[app run];
}return 0;}
