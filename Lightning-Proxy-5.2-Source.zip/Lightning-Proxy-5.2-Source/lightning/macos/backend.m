#import "backend.h"
#include <netdb.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

static NSString *const Base=@"/opt/lightning-proxy";
static NSString *trim(NSString *s){return [s stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];}
static NSURL *resource(NSString *n){return [NSBundle.mainBundle URLForResource:n withExtension:nil];}
static NSData *base64(NSString *s) {
 if(!s.length)return nil;
 s=[[s componentsSeparatedByCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet] componentsJoinedByString:@""];
 s=[[s stringByReplacingOccurrencesOfString:@"-" withString:@"+"] stringByReplacingOccurrencesOfString:@"_" withString:@"/"];
 while(s.length%4)s=[s stringByAppendingString:@"="];
 return [[NSData alloc]initWithBase64EncodedString:s options:0];
}
static NSDictionary *profile(NSString *raw) {
 NSURLComponents *u=[NSURLComponents componentsWithString:[raw stringByReplacingOccurrencesOfString:@"vless\\://" withString:@"vless://"]];
 if(![u.scheme.lowercaseString isEqual:@"vless"]||!u.host.length||u.port.integerValue<1||u.port.integerValue>65535||!u.user.length)return nil;
 if(![[NSUUID alloc]initWithUUIDString:u.user])return nil;
 NSMutableDictionary *q=[NSMutableDictionary dictionary];
 for(NSURLQueryItem *item in u.queryItems)if(item.value&&!q[item.name])q[item.name]=item.value;
 NSString *sid=q[@"sid"]?:@"",*flow=q[@"flow"]?:@"";
 NSCharacterSet *hex=[NSCharacterSet characterSetWithCharactersInString:@"0123456789abcdefABCDEF"];
 if(![q[@"security"] isEqual:@"reality"]||![q[@"sni"] length]||![@[@"",@"tcp",@"raw"] containsObject:q[@"type"]?:@""]||
    ![@[@"",@"xtls-rprx-vision"] containsObject:flow]||![@[@"",@"none"] containsObject:q[@"encryption"]?:@""]||
    ![@[@"",@"none"] containsObject:q[@"headerType"]?:@""]||[q[@"pqv"] length]||[q[@"fm"] length]||
    base64(q[@"pbk"]).length!=32||sid.length>16||sid.length%2||[sid rangeOfCharacterFromSet:hex.invertedSet].location!=NSNotFound)return nil;
 return @{@"host":u.host,@"port":u.port,@"name":u.fragment.length?u.fragment:u.host,@"link":u.string,
   @"user":@{@"id":u.user,@"encryption":@"none",@"flow":flow},
   @"reality":@{@"publicKey":q[@"pbk"],@"serverName":q[@"sni"],@"shortId":sid,@"spiderX":q[@"spx"]?:@"",@"fingerprint":q[@"fp"]?:@"chrome"}};
}
static NSData *command(NSString *binary,NSArray *args) {
 NSTask *task=[NSTask new];task.executableURL=[NSURL fileURLWithPath:binary];task.arguments=args;
 NSPipe *out=[NSPipe pipe];task.standardOutput=out;task.standardError=NSFileHandle.fileHandleWithNullDevice;
 task.standardInput=NSFileHandle.fileHandleWithNullDevice;
 if(![task launchAndReturnError:NULL])return nil;
 NSData *bytes=[out.fileHandleForReading readDataToEndOfFile];[task waitUntilExit];
 return task.terminationStatus==0?bytes:nil;
}
static BOOL approved(void){
 for(NSArray *args in @[@[@"-n",@"-l",[Base stringByAppendingPathComponent:@"tunnel-router"]],
                        @[@"-n",@"-l",[Base stringByAppendingPathComponent:@"system-proxy"]]]){
  if(!command(@"/usr/bin/sudo",args))return NO;
 }
 return YES;
}
static NSDictionary *verify(BOOL direct) {
 NSArray *sites=@[@"https://www.cloudflare.com/cdn-cgi/trace",@"https://www.gstatic.com/generate_204",@"https://example.com/"];
 dispatch_group_t group=dispatch_group_create();
 NSMutableArray *responses=[NSMutableArray array];
 for(NSString *site in sites)dispatch_group_async(group,dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
  NSMutableArray *args=[@[@"-q",@"-fsS",@"--max-time",@"6",@"--max-filesize",@"65536",@"--proto",@"=https",@"--noproxy",direct?@"*":@""] mutableCopy];
  if(!direct)[args addObjectsFromArray:@[@"--proxy",@"http://127.0.0.1:10809"]];
  NSDate *start=[NSDate date]; [args addObjectsFromArray:@[@"--",site]];
  NSData *bytes=command(@"/usr/bin/curl",args);if(!bytes)return;
  NSMutableDictionary *result=[@{@"latency":@((NSInteger)(-[start timeIntervalSinceNow]*1000))} mutableCopy];
  if([site hasSuffix:@"/trace"]){
   NSString *body=[[NSString alloc]initWithData:bytes encoding:NSUTF8StringEncoding];
   for(NSString *line in [body componentsSeparatedByString:@"\n"])if([line hasPrefix:@"ip="]){
    NSString *address=[line substringFromIndex:3];struct in6_addr storage;
    if(inet_pton(AF_INET,address.UTF8String,&storage)==1||inet_pton(AF_INET6,address.UTF8String,&storage)==1)result[@"ip"]=address;
   }
  }
  @synchronized(responses){[responses addObject:result];}
 });
 dispatch_group_wait(group,DISPATCH_TIME_FOREVER);
 for(NSDictionary *r in responses)if(r[@"ip"])return r;
 return responses.firstObject;
}
static NSString *resolve(NSString *host){
 struct addrinfo hints={0},*addresses=NULL;hints.ai_socktype=SOCK_STREAM;hints.ai_family=AF_UNSPEC;
 if(getaddrinfo(host.UTF8String,NULL,&hints,&addresses)!=0)return nil;
 NSString *answer=nil;
 for(int family=AF_INET;family<=AF_INET6&&!answer;family=family==AF_INET?AF_INET6:AF_INET6+1)
  for(struct addrinfo *entry=addresses;entry&&!answer;entry=entry->ai_next){
   char name[NI_MAXHOST];
   if(entry->ai_family==family&&!getnameinfo(entry->ai_addr,entry->ai_addrlen,name,sizeof(name),NULL,0,NI_NUMERICHOST))
    answer=[NSString stringWithUTF8String:name];
  }
 freeaddrinfo(addresses);return answer;
}
static NSString *routeInterface(NSString *ip){
 NSData *output=command(@"/sbin/route",@[@"-n",@"get",[ip containsString:@":"]?@"-inet6":@"-inet",ip]);
 NSString *s=[[NSString alloc]initWithData:output?:[NSData data] encoding:NSUTF8StringEncoding];
 for(NSString *line in [s componentsSeparatedByString:@"\n"]){
  NSString *t=trim(line);if([t hasPrefix:@"interface:"])return trim([t substringFromIndex:10]);
 }
 return nil;
}
static BOOL portState(int port,BOOL reserve) {
 int fd=socket(AF_INET,SOCK_STREAM,0); if(fd<0)return NO;
 struct sockaddr_in addr={0};addr.sin_family=AF_INET;addr.sin_port=htons(port);addr.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
 if(reserve){int yes=1;setsockopt(fd,SOL_SOCKET,SO_REUSEADDR,&yes,sizeof(yes));}
 BOOL ok=(reserve?bind(fd,(const struct sockaddr *)&addr,sizeof(addr)):connect(fd,(const struct sockaddr *)&addr,sizeof(addr)))==0;
 close(fd);return ok;
}
static NSArray *names(NSArray *profiles) {
 NSMutableArray *list=[NSMutableArray array];
 for(NSDictionary *item in profiles)[list addObject:[NSString stringWithFormat:@"%@  ·  %@",item[@"name"],item[@"host"]]];
 return list;
}
@implementation ProxyBackend {
 NSArray *_profiles;
 NSTask *_xray,*_network;
 NSFileHandle *_networkInput;
 BOOL _device;
}
- (NSURL *)profileURL{
 NSURL *support=[NSFileManager.defaultManager URLsForDirectory:NSApplicationSupportDirectory inDomains:NSUserDomainMask].firstObject;
 return [[support URLByAppendingPathComponent:@"Lightning Proxy"] URLByAppendingPathComponent:@"profiles"];
}
- (NSArray *)parseLinks:(NSString *)source {
 source=trim(source);
 if([source hasPrefix:@"\uFEFF"])source=[source substringFromIndex:1];
 if(![source containsString:@"vless://"]&&![source containsString:@"vless\\://"]){
  NSData *decoded=base64(source);
  if(decoded)source=[[NSString alloc]initWithData:decoded encoding:NSUTF8StringEncoding];
 }
 NSMutableArray *profiles=[NSMutableArray array];
 for(NSString *line in [source componentsSeparatedByCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet]){
  NSDictionary *item=profile(line);if(item)[profiles addObject:item];
  if(profiles.count==100)break;
 }
 return profiles;
}
- (void)stop {
 [_networkInput closeAndReturnError:NULL];_networkInput=nil;
 if(_network.running){
  for(int n=0;n<35&&_network.running;n++)[NSThread sleepForTimeInterval:.1];
  if(_network.running)[_network terminate];
 }
 _network=nil;
 if(_xray.running){[_xray terminate];[_xray waitUntilExit];}
 _xray=nil;_device=NO;
}
- (BOOL)active {
 return _xray.running&&(!_network||(_network.running&&(!_device||[routeInterface(@"1.0.0.1") isEqual:@"utun83"])));
}
- (NSDictionary *)connect:(NSDictionary *)request error:(NSString **)error {
 NSInteger index=[request[@"index"] integerValue];
 if(index<0||(NSUInteger)index>=_profiles.count){*error=@"Import and select a profile first.";return nil;}
 if(_xray.running){*error=@"Disconnect the current session first.";return nil;}
 if(!portState(10808,YES)||!portState(10809,YES)){*error=@"Port 10808 or 10809 is in use. Quit the other proxy first.";return nil;}
 _device=[request[@"device"] boolValue];BOOL system=[request[@"system"] boolValue];
 if((_device||system)&&!approved()){*error=@"Network access is required. Use Connect to enable it.";return nil;}
 NSDictionary *item=_profiles[index];NSString *gateway=_device?resolve(item[@"host"]):item[@"host"];
 if(!gateway){*error=@"Could not resolve the gateway address.";return nil;}
 NSDictionary *config=@{@"log":@{@"loglevel":@"warning",@"access":@"none"},@"inbounds":@[
  @{@"listen":@"127.0.0.1",@"port":@10808,@"protocol":@"socks",@"settings":@{@"udp":@YES,@"ip":@"127.0.0.1"}},
  @{@"listen":@"127.0.0.1",@"port":@10809,@"protocol":@"http"}],
  @"outbounds":@[@{@"protocol":@"vless",@"settings":@{@"vnext":@[@{@"address":gateway,@"port":item[@"port"],@"users":@[item[@"user"]]}]},
  @"streamSettings":@{@"network":@"tcp",@"security":@"reality",@"realitySettings":item[@"reality"]}}]};
 NSData *data=[NSJSONSerialization dataWithJSONObject:config options:0 error:NULL];
 NSDictionary *measurement=nil;BOOL listener=NO;
 for(NSString *name in @[@"xray",@"xray-legacy"]){
  _xray=[NSTask new];_xray.executableURL=resource(name);
  _xray.arguments=@[@"run",@"-format",@"json",@"-config",@"stdin:"];
  NSPipe *input=[NSPipe pipe];_xray.standardInput=input;
  _xray.standardOutput=NSFileHandle.fileHandleWithNullDevice;_xray.standardError=NSFileHandle.fileHandleWithNullDevice;
  if(_xray.executableURL&&[_xray launchAndReturnError:NULL]){
   [input.fileHandleForWriting writeData:data error:NULL];[input.fileHandleForWriting closeAndReturnError:NULL];
   for(int i=0;i<40&&_xray.running;i++){
    if(portState(10809,NO)&&portState(10808,NO)){listener=YES;measurement=verify(NO);break;}
    [NSThread sleepForTimeInterval:.08];
   }
  }
  if(measurement&&_xray.running)break;
  measurement=nil;
  if(_xray.running){[_xray terminate];[_xray waitUntilExit];}
 }
 if(!measurement){*error=listener?@"Xray started, but no test site answered through the VLESS gateway. Check your profile or network.":@"Neither Xray binary could open the local proxy. Check macOS security and close other proxies.";return nil;}
 if(_device||system){
  if(_device&&[routeInterface(@"1.0.0.1") hasPrefix:@"utun"]){*error=@"Another tunnel is active. Disconnect it before starting Device Tunnel.";return nil;}
  _network=[NSTask new];_network.executableURL=[NSURL fileURLWithPath:@"/usr/bin/sudo"];
  _network.arguments=@[@"-n",[Base stringByAppendingPathComponent:_device?@"tunnel-router":@"system-proxy"]];
  NSPipe *inPipe=[NSPipe pipe],*outPipe=[NSPipe pipe];_network.standardInput=inPipe;_network.standardOutput=outPipe;
  _network.standardError=NSFileHandle.fileHandleWithNullDevice;
  if(![_network launchAndReturnError:NULL]){*error=@"Could not start the macOS networking helper.";return nil;}
  _networkInput=inPipe.fileHandleForWriting;
  if(_device){
   NSData *setup=[NSJSONSerialization dataWithJSONObject:@{@"ip":gateway,@"quad":request[@"quad"]?:@NO} options:0 error:NULL];
   NSMutableData *line=[setup mutableCopy];[line appendBytes:"\n" length:1];
   [_networkInput writeData:line error:NULL];
   for(int i=0;i<45&&_network.running&&![routeInterface(@"1.0.0.1") isEqual:@"utun83"];i++)[NSThread sleepForTimeInterval:.2];
   if(![self active]||[routeInterface(gateway) isEqual:@"utun83"]){*error=@"The device tunnel could not apply its routes.";return nil;}
   measurement=verify(YES);
   if(!measurement){*error=@"TUN started, but no HTTPS test site replied via the device tunnel.";return nil;}
  } else {
   dispatch_semaphore_t signal=dispatch_semaphore_create(0);
   __block BOOL ready=NO;
   NSFileHandle *output=outPipe.fileHandleForReading;
   dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{
    NSData *line=output.availableData;
    ready=[trim([[NSString alloc]initWithData:line encoding:NSUTF8StringEncoding]) isEqual:@"ready"];
    dispatch_semaphore_signal(signal);
   });
   if(dispatch_semaphore_wait(signal,dispatch_time(DISPATCH_TIME_NOW,5*NSEC_PER_SEC))||!ready){
    *error=@"macOS could not apply the system proxy settings.";return nil;
   }
  }
 }
 NSMutableDictionary *info=[measurement mutableCopy];info[@"host"]=item[@"host"];
 return info;
}
- (NSDictionary *)request:(NSDictionary *)request {
 NSString *action=request[@"action"],*error=nil;
 NSMutableDictionary *result=[NSMutableDictionary dictionary];
 if([action isEqual:@"load"]){
  NSString *saved=[NSString stringWithContentsOfURL:[self profileURL] encoding:NSUTF8StringEncoding error:NULL];
  _profiles=[self parseLinks:saved];result[@"profiles"]=names(_profiles);result[@"tunnelReady"]=@(approved());
 }else if([action isEqual:@"import"]){
  NSString *input=trim(request[@"input"]);
  if([input hasPrefix:@"https://"]){
   NSData *data=command(@"/usr/bin/curl",@[@"-q",@"-fsS",@"-L",@"--max-redirs",@"4",@"--max-time",@"12",@"--max-filesize",@"1048576",@"--proto",@"=https",@"--proto-redir",@"=https",@"-A",@"v2rayN/7.0",@"--",input]);
   input=data.length<=1048576?[[NSString alloc]initWithData:data?:[NSData data] encoding:NSUTF8StringEncoding]:nil;
   if(!input.length)error=@"Could not download the HTTPS subscription.";
  }
  NSArray *profiles=error?nil:[self parseLinks:input];
  if(!error&&!profiles.count)error=@"No valid VLESS REALITY profile over TCP found.";
  if(!error){
   _profiles=profiles;result[@"profiles"]=names(profiles);
   NSURL *url=[self profileURL];
   NSString *links=[[profiles valueForKey:@"link"] componentsJoinedByString:@"\n"];
   if(![NSFileManager.defaultManager createDirectoryAtURL:url.URLByDeletingLastPathComponent withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:NULL]||
      ![links writeToURL:url atomically:YES encoding:NSUTF8StringEncoding error:NULL])
    result[@"warning"]=@"Profile imported. It could not be saved.";
   else chmod(url.fileSystemRepresentation,0600);
  }
 }else if([action isEqual:@"connect"]){
  result[@"info"]=[self connect:request error:&error];
  if(error)[self stop];
 }else if([action isEqual:@"stop"]){[self stop];}
 else if([action isEqual:@"test"]){
  result[@"info"]=[self active]?verify(_device):nil;
  if(!result[@"info"])error=@"No HTTPS test site replied.";
 }
 result[@"active"]=@([self active]);if(error)result[@"error"]=error;
 return result;
}
@end
