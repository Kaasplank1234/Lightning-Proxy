#!/usr/bin/env python3
"""Host the Lightning Proxy interface in GTK WebKit."""
import base64
import os
from pathlib import Path
import queue
import subprocess
import threading

try:
    import gi
    gi.require_version("Gtk", "3.0")
    try:
        gi.require_version("WebKit2", "4.1")
    except ValueError:
        gi.require_version("WebKit2", "4.0")
    from gi.repository import GLib, Gtk, WebKit2
except (ImportError, ValueError) as exc:
    raise SystemExit("Install Python GObject, GTK 3 and WebKit2GTK (4.1 or 4.0). See README.txt.") from exc

directory = Path(__file__).resolve().parent
panel = (directory / "panel.html").as_uri()
engine = subprocess.Popen([str(directory / "proxy-engine")], cwd=directory,
                          stdin=subprocess.PIPE, stdout=subprocess.PIPE)
requests = queue.Queue()

def write_requests():
    with engine.stdin:
        while (request := requests.get()) is not None:
            engine.stdin.write(request.encode("utf-8") + b"\n")
            engine.stdin.flush()

def dispatch_reply(line):
    wire = base64.b64encode(line).decode("ascii")
    view.run_javascript(
        "window.engineReply(JSON.parse(new TextDecoder().decode(Uint8Array.from("
        f"atob('{wire}'),c=>c.charCodeAt(0)))))", None, None, None)
    return False

def read_replies():
    for line in engine.stdout:
        GLib.idle_add(dispatch_reply, line)
    GLib.idle_add(dispatch_reply, b'{"error":"The connection engine stopped."}')

manager = WebKit2.UserContentManager()
manager.register_script_message_handler("engine")
view = WebKit2.WebView.new_with_user_content_manager(manager)

def request(_manager, msg):
    value = msg.get_js_value()
    if value.is_string():
        text = value.to_string()
        if len(text) <= 1100000:
            requests.put(text)

def navigation(_view, decision, kind):
    if kind == WebKit2.PolicyDecisionType.NAVIGATION_ACTION:
        if decision.get_navigation_action().get_request().get_uri() != panel:
            decision.ignore()
            return True
    return False

manager.connect("script-message-received::engine", request)
view.connect("decide-policy", navigation)
window = Gtk.Window(title="Lightning Proxy")
window.set_default_size(790, 490)
window.set_size_request(650, 435)
window.add(view)
window.connect("destroy", Gtk.main_quit)
threading.Thread(target=write_requests, daemon=True).start()
threading.Thread(target=read_replies, daemon=True).start()
view.load_uri(panel)
window.show_all()
try:
    Gtk.main()
finally:
    requests.put(None)
    try:
        engine.wait(timeout=45)
    except subprocess.TimeoutExpired:
        engine.terminate()
        engine.wait()
