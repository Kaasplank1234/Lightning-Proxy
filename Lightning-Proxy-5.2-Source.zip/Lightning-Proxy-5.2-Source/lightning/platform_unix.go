//go:build darwin || linux

package main

import (
	"bufio"
	"encoding/json"
	"errors"
	"io"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
)

// The privileged executable accepts only an IP address and a DNS selector.
var helper = map[string]string{"darwin": "/opt/lightning-proxy/proxy-engine", "linux": "/opt/lightning-proxy/tunnel-helper"}[runtime.GOOS]

const exeSuffix = ""

var tunnelInterface = map[string]string{"darwin": "utun83", "linux": "lightning0"}[runtime.GOOS]

type tunnelRequest struct {
	IP   string
	Quad bool
}

func hidden(path string, args ...string) *exec.Cmd { return exec.Command(path, args...) }
func tunnelAvailable() bool {
	if _, e := os.Stat(helper); e != nil {
		return false
	}
	if exec.Command("/usr/bin/sudo", "-n", "-l", helper, "--router").Run() != nil {
		return false
	}
	if runtime.GOOS == "darwin" {
		if _, e := os.Stat("/opt/lightning-proxy/system-proxy"); e != nil {
			return false
		}
		return exec.Command("/usr/bin/sudo", "-n", "-l", "/opt/lightning-proxy/system-proxy").Run() == nil
	}
	return true
}

func (s *state) startSystemProxy() (err error) {
	if runtime.GOOS != "darwin" || !tunnelAvailable() {
		return errors.New("Enable network access in Lightning Proxy first.")
	}
	s.tun = hidden("/usr/bin/sudo", "-n", "/opt/lightning-proxy/system-proxy")
	s.tunInput, err = s.tun.StdinPipe()
	if err != nil {
		return err
	}
	reader, e := s.tun.StdoutPipe()
	if e != nil {
		s.tunInput.Close()
		return e
	}
	ready := make(chan bool, 1)
	s.tunDone, err = launch(s.tun)
	if err != nil {
		s.tunInput.Close()
		reader.Close()
		return err
	}
	go func() {
		line, e := bufio.NewReader(reader).ReadString('\n')
		ready <- e == nil && strings.TrimSpace(line) == "ready"
	}()
	select {
	case ok := <-ready:
		if ok {
			return nil
		}
	case <-time.After(5 * time.Second):
	}
	return errors.New("macOS could not apply the system proxy settings.")
}
func usesTunnel() bool {
	iface, e := net.InterfaceByName(tunnelInterface)
	if e != nil || iface.Flags&net.FlagUp == 0 {
		return false
	}
	var out []byte
	if runtime.GOOS == "darwin" {
		out, e = exec.Command("/sbin/route", "-n", "get", "-inet", "1.0.0.1").Output()
		for _, line := range strings.Split(string(out), "\n") {
			if key, value, ok := strings.Cut(line, ":"); ok && strings.TrimSpace(key) == "interface" && strings.TrimSpace(value) == tunnelInterface {
				return e == nil
			}
		}
		return false
	}
	out, e = exec.Command("ip", "-o", "route", "get", "1.0.0.1").Output()
	return e == nil && strings.Contains(" "+strings.TrimSpace(string(out))+" ", " dev "+tunnelInterface+" ")
}

func (s *state) startTunnel(ip string, quad bool) (err error) {
	if _, e := os.Stat(helper); e != nil || !tunnelAvailable() {
		return errors.New("Enable Device Tunnel once using the setup instructions in README.txt. Local Proxy is available immediately.")
	}
	sudo := "/usr/bin/sudo"
	s.tun = hidden(sudo, "-n", helper, "--router")
	s.tun.Env = []string{"PATH=/usr/sbin:/usr/bin:/sbin:/bin"}
	s.tunInput, err = s.tun.StdinPipe()
	if err != nil {
		return err
	}
	s.tunDone, err = launch(s.tun)
	if err != nil {
		s.tunInput.Close()
		return errors.New("Could not start the privileged tunnel helper.")
	}
	return json.NewEncoder(s.tunInput).Encode(tunnelRequest{ip, quad})
}

func (s *state) shutdownTunnel() {
	if s.tunInput != nil {
		s.tunInput.Close()
	}
}

func router() {
	if os.Geteuid() != 0 {
		return
	}
	var req tunnelRequest
	dec := json.NewDecoder(io.LimitReader(os.Stdin, 4096))
	if dec.Decode(&req) != nil {
		return
	}
	ip := net.ParseIP(req.IP)
	if ip == nil || !ip.IsGlobalUnicast() {
		return
	}
	dir, e := os.MkdirTemp("", "lightning-router-")
	if e != nil {
		return
	}
	defer os.RemoveAll(dir)
	data, _ := json.Marshal(routing(ip.String(), req.Quad))
	config := filepath.Join(dir, "tun.json")
	if os.WriteFile(config, data, 0600) != nil {
		return
	}
	c := exec.Command("/opt/lightning-proxy/sing-box", "run", "-D", dir, "-c", config)
	c.Dir = dir
	c.Env = []string{"PATH=/usr/sbin:/usr/bin:/sbin:/bin", "HOME=/var/empty"}
	done, e := launch(c)
	if e != nil {
		return
	}
	closed := make(chan struct{})
	go func() { io.Copy(io.Discard, os.Stdin); close(closed) }()
	select {
	case <-done:
		return
	case <-closed:
	}
	_ = c.Process.Signal(syscall.SIGTERM)
	select {
	case <-done:
	case <-time.After(2 * time.Second):
		kill(c, done)
	}
}

func main() {
	path, e := os.Executable()
	if e != nil {
		return
	}
	if len(os.Args) == 2 && os.Args[1] == "--router" {
		router()
		return
	}
	runEngine(filepath.Dir(path))
}
