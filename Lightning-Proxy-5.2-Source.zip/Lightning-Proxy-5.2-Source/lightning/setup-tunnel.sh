#!/bin/sh
set -eu
[ "$(id -u)" -ne 0 ] || { echo 'Run this script as your regular account. It will ask for sudo once.' >&2; exit 1; }
user=$(id -un)
case "$user" in ''|*[!a-zA-Z0-9_.-]*|-*) echo 'Unsupported account name.' >&2; exit 1;; esac
here=$(cd "$(dirname "$0")" && pwd)
if [ "$#" -gt 0 ]; then
  [ "$#" -eq 1 ] && [ "$1" = "--remove" ] || exit 64
  sudo /bin/rm -f "/etc/sudoers.d/lightning-proxy-$(id -u)"
  echo 'Device Tunnel authorization was removed for this account.'
  exit
fi
app="$here/Lightning Proxy.app/Contents/Resources"
[ -f "$app/proxy-engine" ] || app="$here"
[ -f "$app/proxy-engine" ] && [ -f "$app/sing-box" ] || { echo 'Keep this script next to the app files.' >&2; exit 1; }
sudo -v
sudo /usr/bin/install -d -m 0755 -o root /opt/lightning-proxy
sudo /usr/bin/install -m 0755 -o root "$app/proxy-engine" /opt/lightning-proxy/tunnel-helper
sudo /usr/bin/install -m 0755 -o root "$app/sing-box" /opt/lightning-proxy/sing-box
tmp=$(mktemp)
trap 'rm -f "$tmp"' EXIT HUP INT TERM
printf '%s ALL=(root) NOPASSWD: /opt/lightning-proxy/tunnel-helper --router\n' "$user" >"$tmp"
sudo /usr/sbin/visudo -cf "$tmp"
sudo /usr/bin/install -m 0440 -o root "$tmp" "/etc/sudoers.d/lightning-proxy-$(id -u)"
echo 'Device Tunnel is ready. Open Lightning Proxy and select Device Tunnel.'
