# Building Lightning Proxy 5.2

This archive contains the Lightning Proxy frontend, platform launchers, proxy engine and networking helpers. The release packages supply the runtime binaries and icons. To test a development build, start with a copy of the matching [5.2 release package](https://github.com/Kaasplank1234/Lightning-Proxy/releases/tag/Download) and replace the application files as described below.

The Go components use the standard library. The release toolchain uses Go 1.24.13. Run these commands from the source archive's top-level directory, using a shell with the `go` executable on its path.

## Linux x64

```sh
cd lightning
CGO_ENABLED=0 GOOS=linux GOARCH=amd64 go build -o ../proxy-engine engine.go platform_unix.go
```

In a copy of the extracted Linux release directory, replace `proxy-engine` with the compiled binary, copy `linux.py` as `lightning-proxy`, copy `setup-tunnel.sh` as `Setup-Tunnel.sh`, and replace `panel.html`. Make those executables runnable with `chmod +x proxy-engine lightning-proxy Setup-Tunnel.sh`. Keep the release's Xray and sing-box binaries in the same directory. The launcher uses Python 3 with PyGObject, GTK 3 and WebKitGTK.

## Windows x64

The following commands use a POSIX shell and can cross-compile the Windows binaries.

```sh
cd lightning
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -o ../proxy-engine.exe engine.go platform_windows.go
cd windows-launcher
CGO_ENABLED=0 GOOS=windows GOARCH=amd64 go build -ldflags=-H=windowsgui -o "../../Lightning Proxy.exe" main.go
```

Replace both EXEs in a copy of the extracted Windows release. Keep `xray.exe`, `sing-box.exe`, `wintun.dll` and the icon alongside them. The launcher embeds `lightning/windows-launcher/panel.ps1` and uses Windows PowerShell.

## macOS

Run these commands on macOS with Xcode Command Line Tools. Build on the target architecture, or change `arch` to `arm64` or `x86_64` to match the app bundle you are updating.

```sh
arch=$(uname -m)
cd lightning/macos
xcrun clang -arch "$arch" -mmacosx-version-min=11.0 -fobjc-arc \
  -framework AppKit -framework QuartzCore main.m backend.m -o lightning-proxy
xcrun clang -arch "$arch" -mmacosx-version-min=11.0 -fobjc-arc \
  -framework Foundation -framework SystemConfiguration system-proxy.m -o system-proxy
xcrun clang -arch "$arch" -mmacosx-version-min=11.0 -fobjc-arc \
  -framework Foundation tunnel-router.m -o tunnel-router
```

Copy the matching release's `Lightning Proxy.app` to a writable folder. Replace `Contents/MacOS/lightning-proxy` with the new executable. Replace `system-proxy`, `tunnel-router` and `install-helper.sh` in `Contents/Resources`. Keep the bundle metadata, icon and matching Xray and sing-box binaries. Run `codesign --force --sign - "/path/to/Lightning Proxy.app"` on the updated bundle for local development.

## Third-party components

- [Xray-core 26.9.9](https://github.com/XTLS/Xray-core/tree/v26.9.9)
- [Xray-core 25.8.3](https://github.com/XTLS/Xray-core/tree/v25.8.3) for the macOS fallback
- [sing-box 1.12.25](https://github.com/SagerNet/sing-box/tree/v1.12.25), built on macOS with the `with_gvisor` tag
- [Wintun 0.14.1](https://www.wintun.net/) for Windows

The included notices apply to these upstream components. No license for Lightning Proxy's own source code is included.
